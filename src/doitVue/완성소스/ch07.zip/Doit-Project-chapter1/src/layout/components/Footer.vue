<template>
    <footer>
        <div class="botinfo">
            <div class="botbtngroup">
                <button class="btn-text">찾아오시는 길</button>
                <button class="btn-text">개인정보취급방침</button>
                <button class="btn-text">이용 약관</button>
                <button class="btn-gray">저자 신청</button>
                <button class="btn-gray">역자 신청</button>
                <button class="btn-gray">교재 샘플/강의자료 신청</button>
            </div>
        </div>
        <div class="footerinfo">
            <div class="footer-logo"><img src="/images/footer-logo.png" /></div>
            <div class="footer-sub">
                <address>
                    서울시 마포구 잔다리로 109 이지스퍼블리싱 <span>Tel 02-1234-12345</span>
                </address>
                <p>Email email@email.com</p>
                <p>통신판매업 신고 : 2020-서울강남-001234</p>
            </div>
        </div>
    </footer>
</template>