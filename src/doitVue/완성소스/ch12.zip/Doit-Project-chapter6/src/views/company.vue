<template>
    <Subpage :pagetit="'회사 소개'">
        <div class="company">
            <div class="introcon">
                <div class="introgroup">
                <strong><i class="bi bi-people-fill"></i> “사람을 구체적으로 도와주는 책”</strong>
                <p>
                    이지스퍼블리싱(주)의 책에는 ‘사람들에게 구체적으로 도움이 되는 책’을 만든다는 출판 가치가 담겨 있습니다.<br />
                    2010년 5월 출범한 이지스퍼블리싱(주)는 크게 두 영역의 책을 출간합니다. IT 실용 도서와 학습 분야 도서입니다.<br />
                    IT 교재와 사진 책 등 실용서는 이지스퍼블리싱 브랜드로, 학습과 자녀교육 도서는 이지스에듀 브랜드로 출간하고 있습니다.
                </p>
                </div>
                <div class="introgroup">
                <strong><i class="bi bi-camera-reels-fill"></i> 이지스퍼블리싱의 미션</strong>
                <p>
                    사람에게 구체적으로 도움을 주는 책<br />
                    우리는 열심히 사는 사람들에게 도움이 되고 싶습니다.<br />
                    우리는 책을 출간하기 전에 질문할 것입니다.<br />
                    "이 책이 사람들에게 도움이 됩니까?"<br /><br />

                    정보의 지름길을 만들어 빠르게 원하는 곳으로 가도록 도와주는 책.<br />
                    손에 잡히는 이익을 얻을 수 있도록 도움이 되는 책을 만들고 싶습니다.
                </p>
                </div>
                <div class="introgroup">
                <strong><i class="bi bi-diagram-3-fill"></i> 조직관</strong>
                <p>
                    이지스퍼블리싱(주)에 참여하는 모든 사람에게 도움을 주고 싶습니다.<br />
                    함께 참여해서 만드는 기쁨, 세상에 도움을 주는 뿌듯함을 느끼며 책을 만들고,<br />
                    우리의 미래를 원하는 대로 스스로 만드는 터전.<br />
                    기여한 바, 공정한 분배가 이루어지고 영광을 함께 나누는 곳. 그곳이 바로 이지스퍼블리싱(주)입니다.
                </p>
                </div>
            </div>
        </div>
    </Subpage>
</template>
<script>
import Subpage from "@/layout/components/Subpage.vue";
export default {
components: { Subpage },
};
</script>