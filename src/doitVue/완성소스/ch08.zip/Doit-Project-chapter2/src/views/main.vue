<template>
    <section class="maincontents">메인 영역</section>
</template>