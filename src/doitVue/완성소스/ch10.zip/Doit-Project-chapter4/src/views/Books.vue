<template>
    <Subpage :pagetit="'도서 소개'">
        <div class="bookpage">도서 소개</div>
    </Subpage>
</template>
<script>
import Subpage from "@/layout/components/Subpage.vue";
export default {
    components: {
        Subpage,
    },
};
</script>
