<template>
  <div id="appPage">
	  <router-view/>
  </div>
</template>
